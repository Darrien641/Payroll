﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Runtime.InteropServices.ComTypes;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Runtime.Serialization;
using System.Text;

namespace Payroll
{
    public class Employer
    {
        decimal EmpSalary = 0.0m;
        decimal EmpWage = 0.0m;
        decimal HourlyNetPay = 0.0m;
        decimal SalaryNetPay = 0.0m;
        decimal salaryFICA = 0.0m;
        decimal hourlyFICA = 0.0m;
        decimal salaryTaxes = 0.0m;
        decimal hourlyTaxes = 0.0m;
        List<SalariedEmployee> SalariedEmp = new List<SalariedEmployee>();
        List<HourlyEmployee> HourlyEmp = new List<HourlyEmployee>();
        public string AddEmp(Employee employee)
        {
            if (employee is SalariedEmployee)
            {
                SalariedEmp.Add((SalariedEmployee)employee);
                return "Salary employee " + employee.Name + " Has Been added\n";
            }
            else
            {
                HourlyEmp.Add((HourlyEmployee)employee);
                return "Hourly wage employee " + employee.Name + " Has Been added\n";
            }

        }

        public IEnumerable<SalariedEmployee> GetSalariedEmployees()
        {
            return SalariedEmp;
        }

        public string GetSalariedNetPayroll()
        {

            foreach (SalariedEmployee emp in SalariedEmp)
            {
                SalaryNetPay += decimal.Parse(emp.CalculatePay().Replace("$", ""));
            }
            return $"Net Salaried Payroll: {SalaryNetPay:$00.00}";
        }
        public string GetSalariedFICA()
        {

            foreach (SalariedEmployee emp in SalariedEmp)
            {
                salaryFICA += emp.MonthlyPay * emp.FICA;
            }
            return $"Total Salaried FICA paid: {salaryFICA:$00.00}";
        }
        public string GetSalariedFedTax()
        {

            foreach (SalariedEmployee emp in SalariedEmp)
            {
                salaryTaxes += emp.MonthlyPay * emp.FedTax;
            }
            return $"Total Federal Tax withheld for Salaried employees: {salaryTaxes:$00.00} ";
        }
        public IEnumerable<HourlyEmployee> GetHourlyEmployees()
        {
            return HourlyEmp;
        }
        public string GetSalariedGrossPayroll()
        {

            foreach (SalariedEmployee emp in SalariedEmp)
            {
                EmpSalary += emp.MonthlyPay;
            }
            return $"Gross Salary Payroll: {EmpSalary:$00.00}";
        }
        public string GetHourlyGrossPayroll()
        {
            foreach (HourlyEmployee emp in HourlyEmp)
            {
                EmpWage += emp.HourlyPay * emp.HoursWorked;
            }
            return $"Gross Hourly Payroll: {EmpWage:$00.00}";
        }
        public string GetHourlyNetPayroll()
        {
            foreach (HourlyEmployee emp in HourlyEmp)
            {
                HourlyNetPay += decimal.Parse(emp.CalculatePay().Replace("$", ""));
            }
            return $"Net Hourly Payroll: {HourlyNetPay:$00.00}";
        }
        public string GetHourlyFICA()
        {
            foreach (HourlyEmployee emp in HourlyEmp)
            {
                hourlyFICA += (emp.HourlyPay * emp.HoursWorked) * emp.FICA;
            }
            return $"Total Hourly FICA paid: {hourlyFICA:$00.00}";
        }
        public string GetHourlyFedTax()
        {
            foreach (HourlyEmployee emp in HourlyEmp)
            {
                hourlyTaxes += (emp.HourlyPay * emp.HoursWorked) * emp.FedTax;
            }
            return $"Total Federal Tax withheld for hourly employees: {hourlyTaxes:$00.00}";
        }

        public string GetTotalGross()
        {
            return $"Total Gross Pay: {EmpSalary + EmpWage:$00.00}\n";
        }
        public string GetTotalNet()
        {
            return $"Total Net Pay: {SalaryNetPay + HourlyNetPay:$00.00}\n";
        }

        public string GetTotalFICA()
        {
            return $"Total FICA Paid: {hourlyFICA + salaryFICA:$00.00}\n";
        }
        public string GetTotalFedTax()
        {
            return $"Total Federal Taxes Witheld: {hourlyTaxes + salaryTaxes:$00.00}\n";
        }

    }
}
