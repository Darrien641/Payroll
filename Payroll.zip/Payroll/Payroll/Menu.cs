﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;

namespace Payroll
{
    public static class Menu
    {
        public readonly static string[] EmpInfo = new string[]
        {
            "Enter Employee Last Name: ",
            "Enter Employee First Name: ",
            "Enter Employee Age: ",
            "Enter Employee ID: ",
            "Enter Employee Monthly Salary: ",
            "Enter Employee Hourly Wage: ",
            "Enter Employee Hours Worked: ",
        };
        private readonly static string[] MonthlyEmp = new string[]
        {
            EmpInfo[0],
            EmpInfo[1],
            EmpInfo[2],
            EmpInfo[3],
            EmpInfo[4],
        };
        private readonly static string[] HourlyEmp = new string[]
        {
            EmpInfo[0],
            EmpInfo[1],
            EmpInfo[2],
            EmpInfo[3],
            EmpInfo[5],
            EmpInfo[6],
        };
        public static IEnumerable<string> GetHourlyEmp()
        {
            return HourlyEmp;
        }
        public static IEnumerable<string> GetMonthlyEmp()
        {
            return MonthlyEmp;
        }
    }
}
