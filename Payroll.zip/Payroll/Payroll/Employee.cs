﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Payroll
{
    public abstract class Employee
    {
        private readonly decimal fedTax;
        public decimal FedTax { get { return fedTax; } }
        private readonly decimal fica;
        public decimal FICA { get { return fica; } }
        private readonly string name;
        public string Name { get { return name; } }
        private readonly int age;
        public int Age { get { return age; } }
        private readonly int employeeID;
        public int EmployeeID { get { return employeeID; } }
        public Employee(string Firstname, string Lastname, int Age, int EmployeeID)
        {
            name = Lastname + ", " + Firstname;
            age = Age;
            employeeID = EmployeeID;
            fica = .0765m;
            fedTax = .265m;
        }

        public abstract string CalculatePay();
    }
}
