﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Payroll
{
    public class SalariedEmployee : Employee
    {
        private readonly decimal monthlyPay;

        public decimal MonthlyPay
        {
            get { return monthlyPay; }
        }

        public SalariedEmployee(string Firstname, string Lastname, int Age, int EmployeeID, decimal MonthlyPay) : base(Firstname, Lastname, Age, EmployeeID)
        {
            monthlyPay = MonthlyPay;
        }

        public override string CalculatePay()
        {
            decimal pay = 0.0m;
            decimal Tax = 0.0m;
            pay = MonthlyPay;
            Tax = pay * FICA;
            Tax += pay * FedTax;
            pay -= Tax;
            return $"{pay:$00.00}";
        }
    }
}
