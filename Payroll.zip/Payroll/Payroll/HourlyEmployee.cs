﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace Payroll
{
    public class HourlyEmployee : Employee
    {
        private readonly decimal hoursWorked;
        public decimal HoursWorked { get { return hoursWorked; } }

        private readonly decimal hourlyPay;
        public decimal HourlyPay { get { return hourlyPay; } }
        decimal pay = 0.0m;
        decimal Tax = 0.0m;
        public HourlyEmployee(string Firstname, string Lastname, int Age, int EmployeeID, decimal HoursWorked, decimal HourlyPay) : base(Firstname, Lastname, Age, EmployeeID)
        {
            hourlyPay = HourlyPay;
            hoursWorked = HoursWorked;
        }

        public override string CalculatePay()
        {

            pay = (HoursWorked * HourlyPay);
            Tax = pay * FICA;
            Tax += pay * FedTax;
            pay -= Tax;
            return $"{pay:$00.00}";
        }
    }
}
