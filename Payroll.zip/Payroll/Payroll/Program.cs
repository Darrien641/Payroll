﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Payroll
{
    public class Program
    {
        static Employer employer = new Employer();
        static string Monthly = "MONTHLY";
        static string Hourly = "HOURLY";
        static string Report = "REPORT";
        static string firstName;
        static string lastName;
        static int age;
        static int id;
        static decimal salary;
        static decimal hours;
        static decimal hourlyPay;

        public static string AddMonthly()
        {

            firstName = string.Empty;
            lastName = string.Empty;
            age = 0;
            id = 0;
            salary = 0.0m;

            Console.WriteLine("Please enter Employee Data as prompted");
            foreach (string Item in Menu.GetMonthlyEmp())
            {

                Console.WriteLine(Item);
                if (Item == Menu.EmpInfo[0])
                {
                    lastName = Console.ReadLine();
                }
                if (Item == Menu.EmpInfo[1])
                {
                    firstName = Console.ReadLine();
                }
                if (Item == Menu.EmpInfo[2])
                {
                    age = int.Parse(Console.ReadLine());
                }
                if (Item == Menu.EmpInfo[3])
                {
                    id = int.Parse(Console.ReadLine());
                }
                if (Item == Menu.EmpInfo[4])
                {
                    salary = decimal.Parse(Console.ReadLine());
                }
            }
            return
                employer.AddEmp(
                    new SalariedEmployee(firstName, lastName, age, id, salary)) + "\n";
        }
        public static string AddSalaried()
        {
            firstName = string.Empty;
            lastName = string.Empty;
            age = 0;
            id = 0;
            hours = 0.0m;
            hourlyPay = 0.0m;
            Console.WriteLine("Please enter Employee Data as prompted");
            foreach (string Item in Menu.GetHourlyEmp())
            {

                Console.WriteLine(Item);
                if (Item == Menu.EmpInfo[0])
                {
                    lastName = Console.ReadLine();
                }
                if (Item == Menu.EmpInfo[1])
                {
                    firstName = Console.ReadLine();
                }
                if (Item == Menu.EmpInfo[2])
                {
                    age = int.Parse(Console.ReadLine());
                }
                if (Item == Menu.EmpInfo[3])
                {
                    id = int.Parse(Console.ReadLine());
                }
                if (Item == Menu.EmpInfo[5])
                {
                    hourlyPay = decimal.Parse(Console.ReadLine());
                }
                if (Item == Menu.EmpInfo[6])
                {
                    hours = decimal.Parse(Console.ReadLine());
                }
            }
            return
                employer.AddEmp(
                    new HourlyEmployee(firstName, lastName, age, id, hours, hourlyPay)) + "\n";
        }
        public static string SalariedReport()
        {
            string Employees = string.Empty;
            string Report = string.Empty;

            foreach (SalariedEmployee EmpS in employer.GetSalariedEmployees())
            {
                Employees += $"Name: {EmpS.Name}, Age: {EmpS.Age}, ID: {EmpS.EmployeeID}, NetPay: {EmpS.CalculatePay()}, GrossPay: {EmpS.MonthlyPay:$00.00}\n";
            }
            Report +=
                $"{employer.GetSalariedGrossPayroll()}\n" +
                $"{employer.GetSalariedNetPayroll()}\n" +
                $"{employer.GetSalariedFedTax()}\n" +
                $"{employer.GetSalariedFICA()}\n\n";
            return "Salaried Employees: \n\n" + Employees + Report;
        }
        public static string HourlyReport()
        {
            string Employees = string.Empty;
            string Report = string.Empty;

            foreach (HourlyEmployee EmpH in employer.GetHourlyEmployees())
            {
                Employees += $"Name: {EmpH.Name}, Age: {EmpH.Age}, ID: {EmpH.EmployeeID}, NetPay: {EmpH.CalculatePay()}, GrossPay: {EmpH.HourlyPay * EmpH.HoursWorked:$00.00} \n";
            }
            Report +=
                $"{employer.GetHourlyGrossPayroll()}\n" +
                $"{employer.GetHourlyNetPayroll()}\n" +
                $"{employer.GetHourlyFedTax()}\n" +
                $"{employer.GetHourlyFICA()}\n\n";
            return "Hourly Employees: \n\n" + Employees + Report;
        }
        public static string GetReport()
        {
            return $"Payroll for ALL Employees:\n\n" +
                $"{employer.GetTotalGross()}" +
                $"{employer.GetTotalNet()}" +
                $"{employer.GetTotalFedTax()}" +
                $"{employer.GetTotalFICA()}";
        }

        public static void Main(string[] args)
        {

            bool isRunning = true;

            while (isRunning)
            {
                Console.WriteLine("Would you like to add an hourly or monthly waged employee?");
                Console.WriteLine("Or would you like to run a report(Type Monthly,Hourly or Report to choose).");
                string input = Console.ReadLine();

                if (input.ToUpper() == Monthly)
                {
                    //string MonthlyEmp = AddMonthly(input);
                    Console.WriteLine(AddMonthly());
                }
                if (input.ToUpper() == Hourly)
                {
                    Console.WriteLine(AddSalaried());
                }
                if (input.ToUpper() == Report)
                {
                    Console.WriteLine(HourlyReport() + SalariedReport() + GetReport());
                }

            }
        }

    }
}
