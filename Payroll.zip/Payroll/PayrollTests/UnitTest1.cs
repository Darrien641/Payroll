using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Payroll;
using System.Collections.Generic;
using System.Xml.XPath;
using System.ComponentModel;

namespace PayrollTest
{
    [TestClass]
    public class PayrollTests
    {
        Employer e = new Employer();
        List<SalariedEmployee> SalariedList = new List<SalariedEmployee>();
        List<HourlyEmployee> HourlyList = new List<HourlyEmployee>();
        List<Employee> EmpList = new List<Employee>();
        SalariedEmployee Salaried = new SalariedEmployee("George", "Smith", 45, 100, 900.50m);
        HourlyEmployee Hourly = new HourlyEmployee("Jeff", "Johnson", 20, 200, 35, 20.25m);

        [TestMethod]
        public void VerifySalariedEmp()
        {
            EmpList.Add(Salaried);
            var result = e.AddEmp(EmpList[0]);

            Assert.IsTrue(result is string);

        }
        [TestMethod]
        public void VerifyHourlyEmp()
        {
            EmpList.Add(Hourly);
            var result = e.AddEmp(EmpList[0]);

            Assert.IsTrue(result is string);

        }
        [TestMethod]
        public void VerifySalariedEmpList()
        {
            var SalaryEmps = e.GetSalariedEmployees();
            foreach (var Emp in SalaryEmps)
            {
                Assert.IsNotNull(Emp);
            }
        }
        [TestMethod]
        public void VerifyHourlyEmpList()
        {
            var HourlyEmps = e.GetHourlyEmployees();
            foreach (var Emp in HourlyEmps)
            {
                Assert.IsNotNull(Emp);
            }
        }
        [TestMethod]
        public void VerifySalariedNetPayRoll()
        {
            EmpList.Add(Salaried);
            var result = e.GetSalariedNetPayroll();

            Assert.IsTrue(result is string);

        }

        [TestMethod]
        public void VerifyHourlyNetPayRoll()
        {
            EmpList.Add(Hourly);
            var result = e.GetHourlyNetPayroll();

            Assert.IsTrue(result is string);

        }
        [TestMethod]
        public void VerifySalariedObj()
        {
            var result = Salaried;
            Assert.IsTrue(result is SalariedEmployee);
            Assert.IsTrue(result is Employee);
        }
        [TestMethod]
        public void VerifyHourlyObj()
        {
            var result = Hourly;
            Assert.IsTrue(result is HourlyEmployee);
            Assert.IsTrue(result is Employee);
        }

        [TestMethod]
        public void VerifyCalculcateHourlyPay()
        {
            var result = Hourly.CalculatePay();
            Assert.IsTrue(result is string);
        }
        [TestMethod]
        public void VerifyEmpAge()
        {
            var result = Hourly.Age;
            result = 9;
            Assert.AreEqual(result, 9);
        }
        [TestMethod]
        public void VerifyEmpID()
        {
            var result = Hourly.EmployeeID;
            result = 9;
            Assert.AreEqual(result, 9);
        }
        [TestMethod]
        public void VerifyCalculcateSalariedPay()
        {
            var result = Salaried.CalculatePay();
            Assert.IsTrue(result is string);
        }
        [TestMethod]
        public void VerifySalariedFica()
        {
            var result = e.GetSalariedFICA();
            Assert.IsTrue(result is string);
        }
        [TestMethod]
        public void VerifyHourlyFica()
        {
            var result = e.GetHourlyFICA();
            Assert.IsTrue(result is string);
        }
        [TestMethod]
        public void VerifySalariedFedTax()
        {
            var result = e.GetSalariedFedTax();
            Assert.IsTrue(result is string);
        }
        [TestMethod]
        public void VerifyHourlyFedTax()
        {
            var result = e.GetHourlyFedTax();
            Assert.IsTrue(result is string);
        }
        [TestMethod]
        public void VerifySalariedGrossPay()
        {
            var result = e.GetSalariedGrossPayroll();
            Assert.IsTrue(result is string);
        }
        [TestMethod]
        public void VerifyHourlyGrossPay()
        {
            var result = e.GetHourlyGrossPayroll();
            Assert.IsTrue(result is string);
        }
        [TestMethod]
        public void VerifyTotalGrossPay()
        {
            var result = e.GetTotalGross();
            Assert.IsTrue(result is string);
        }
        [TestMethod]
        public void VerifyTotalNet()
        {
            var result = e.GetTotalNet();
            Assert.IsTrue(result is string);
        }
        [TestMethod]
        public void VerifyTotalFICA()
        {
            var result = e.GetTotalFICA();
            Assert.IsTrue(result is string);
        }
        [TestMethod]
        public void VerifyTotalFedTax()
        {
            var result = e.GetTotalFedTax();
            Assert.IsTrue(result is string);
        }
        [TestMethod]
        public void VerifySalariedReport()
        {
            var result = Program.SalariedReport();
            Assert.IsTrue(result is string);
        }

        [TestMethod]
        public void VerifyHourlyReport()
        {
            var result = Program.HourlyReport();
            Assert.IsTrue(result is string);
        }

        [TestMethod]
        public void VerifyReport()
        {
            var result = Program.GetReport();
            Assert.IsTrue(result is string);
        }


    }
}